# 补充数据

正式主分析为 867 条靶点对观察，CAP5 为 861 条支持性分析观察。
Current_scores/CURRENT_SCORES_S1_S5.csv 是从当前正式人群表复制的完整双端评分；较大数值更有利。
S1=M0，S2=M1，S3=M2，S4=M1b，S5=M3。原始来源 CSV 保留 M 编号。
Numbered_tables/ 保存正文 2 张表及 SI 10 张表各面板的数值，表中显示精度不改变来源文件精度。
Dual_Target_Docking/results/current/chemical_diversity_cap5_20261023/ 含完整 CAP5 评分方法比较、化学 OOF 及联合排序，包括单独的 CAP5_MODULE_I_METHOD_COMPARISON.csv。
活性来源目录中的 805 行历史核查附件仅通过当前 867 行 crosswalk 使用其匹配成员，不是另一套当前评价集。
receptor_registry.csv 的旧 run_id 不决定结构来源；结构和盒参数对应 V4.2 正式资产。
冻结文件中的旧规模或 PM48 条件仅保留为方法来源；当前成员与有效统计以 results/current 和 Q110 当前人群为准。
本包不包含完整 ChEMBL 数据库、全部对接姿态或分子结构文件；这些文件的位置见分支中既有路径说明。
